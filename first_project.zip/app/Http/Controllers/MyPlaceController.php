<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyPlaceController
{
    public function index() {
        return "my-place-text";
    }
}
