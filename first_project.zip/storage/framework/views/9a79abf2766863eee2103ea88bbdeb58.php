<?php $__env->startSection('content'); ?>

<div>
      <div><?php echo e($post->id); ?>.  <?php echo e($post->title); ?></div>
      <div><?php echo e($post->contet); ?></div>
</div>
<div>
    <a class='btn btn-primary mb-3' href="<?php echo e(route('post.edit', $post->id)); ?>">Изменить</a>
</div>

<div>
    <form class="mb-3" action="<?php echo e(route('post.delete', $post->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <input type="submit" value="Удалить" class="btn btn-danger">
    </form>
</div>

    <div>
        <a class='btn btn-primary' href="<?php echo e(route('post.index')); ?>">Назад</a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\first_project\resources\views/post/show.blade.php ENDPATH**/ ?>