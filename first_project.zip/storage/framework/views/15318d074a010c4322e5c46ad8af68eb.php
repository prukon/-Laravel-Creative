<?php $__env->startSection('content'); ?>
    <div>
        this is contacts
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\first_project\resources\views/contacts.blade.php ENDPATH**/ ?>