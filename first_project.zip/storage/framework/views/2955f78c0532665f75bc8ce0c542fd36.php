<?php $__env->startSection('content'); ?>

    <div>
        <form action="<?php echo e(route('post.update', $post->id)); ?>" method="post">

            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" name="title" class="form-control" id="title" value="<?php echo e($post->title); ?>">
            </div>

            <div class="mb-3">
                <label for="content" class="form-label">content</label>
                <textarea name="content" class="form-control" id="content" ><?php echo e($post->content); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="Image" class="form-label">Image</label>
                <input type="text" name="image" class="form-control" id="Image" value="<?php echo e($post->image); ?>">
            </div>

            <div class="mb-3">
                <label for="Likes" class="form-label">Likes</label>
                <input type ="number" name="likes" class="form-control" id="Likes" value="<?php echo e($post->likes); ?>">
            </div>



            <button type="submit" class="btn btn-primary">Изменить</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\first_project\resources\views/post/edit.blade.php ENDPATH**/ ?>