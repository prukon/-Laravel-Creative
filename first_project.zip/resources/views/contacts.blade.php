@extends('layouts/main')

@section('content')
    <div>
        this is contacts
    </div>
@endsection
