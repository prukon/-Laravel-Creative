@extends('layouts/main')

@section('content')
    <div>
        this is about
    </div>
@endsection
